/**
 * Simple calculator for testing
 */

function add(a, b) {
    return a + b;
}

function subtract(a, b) {
    return a - b;
}

function multiply(a, b) {
    return a * b;
}

function divide(a, b) {
    if (b === 0) {
        throw new Error('Division by zero');
    }
    return a / b;
}

function calculate(operation, x, y) {
    if (operation === 'add') {
        return add(x, y);
    } else if (operation === 'subtract') {
        return subtract(x, y);
    } else if (operation === 'multiply') {
        return multiply(x, y);
    } else if (operation === 'divide') {
        return divide(x, y);
    } else {
        return 'Invalid operation';
    }
}

// Example usage
const result = calculate('add', 5, 3);
console.log('Result:', result);

module.exports = { add, subtract, multiply, divide, calculate };