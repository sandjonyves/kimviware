from ortools.sat.python import cp_model
import json

# =========================
# 1. Charger les données
# =========================

with open("rooms.json", "r", encoding="utf-8") as f:
    rooms_data = json.load(f)

with open("subject.json", "r", encoding="utf-8") as f:
    subjects_data = json.load(f)

rooms = rooms_data["Informatique"]

days = list(range(6))   # 0=Mon ... 5=Sat
periods = list(range(5))  # 0..4

# =========================
# 2. Extraire cours + classes
# =========================

classes = []
curriculum = {}

for level in subjects_data["niveau"]:
    for sem in subjects_data["niveau"][level]:
        class_id = f"L{level}_{sem}"
        classes.append(class_id)

        curriculum[class_id] = []
        for subj in subjects_data["niveau"][level][sem]["subjects"]:
            if isinstance(subj.get("code"), str) and subj.get("code") != "":
                curriculum[class_id].append(subj["code"])

# Flatten all courses
all_courses = set()
course_teacher = {}

for level in subjects_data["niveau"]:
    for sem in subjects_data["niveau"][level]:
        for subj in subjects_data["niveau"][level][sem]["subjects"]:
            code = subj.get("code")
            if isinstance(code, str) and code:
                all_courses.add(code)
                course_teacher[code] = subj.get("Course Lecturer", [""])[0]

all_courses = list(all_courses)

# =========================
# 3. Modèle CP-SAT
# =========================

model = cp_model.CpModel()

# x[c,d,p,r,s]
x = {}

for c in classes:
    for course in curriculum[c]:
        for d in days:
            for p in periods:
                for r in range(len(rooms)):
                    x[(c, course, d, p, r)] = model.NewBoolVar(
                        f"x_{c}_{course}_{d}_{p}_{r}"
                    )

# =========================
# 4. Contraintes
# =========================

# (1) Une classe = une seule activité par période
for c in classes:
    for d in days:
        for p in periods:
            model.Add(
                sum(
                    x[(c, course, d, p, r)]
                    for course in curriculum[c]
                    for r in range(len(rooms))
                ) <= 1
            )

# (2) Chaque cours doit apparaître exactement 1 fois par semaine
for c in classes:
    for course in curriculum[c]:
        model.Add(
            sum(
                x[(c, course, d, p, r)]
                for d in days
                for p in periods
                for r in range(len(rooms))
            ) <= 1
        )

# (3) Une salle ne peut être utilisée qu'une fois par période
for r in range(len(rooms)):
    for d in days:
        for p in periods:
            model.Add(
                sum(
                    x[(c, course, d, p, r)]
                    for c in classes
                    for course in curriculum[c]
                ) <= 1
            )

# =========================
# 5. Objectif : maximiser cours le matin
# =========================

weights = [5, 4, 3, 2, 1]  # priorité matin

model.Maximize(
    sum(
        weights[p] * x[(c, course, d, p, r)]
        for c in classes
        for course in curriculum[c]
        for d in days
        for p in periods
        for r in range(len(rooms))
    )
)

# =========================
# 6. Résolution
# =========================

solver = cp_model.CpSolver()
solver.parameters.max_time_in_seconds = 30

status = solver.Solve(model)

# =========================
# 7. Affichage résultat
# =========================

if status in [cp_model.OPTIMAL, cp_model.FEASIBLE]:
    print("\n📅 EMPLOI DU TEMPS GÉNÉRÉ\n")

    for c in classes:
        print("\n======================")
        print("CLASSE:", c)
        print("======================")

        for d in days:
            for p in periods:
                for r in range(len(rooms)):
                    for course in curriculum[c]:
                        if solver.Value(x[(c, course, d, p, r)]) == 1:
                            print(
                                f"Jour {d} | Période {p} | "
                                f"Cours {course} | Salle {rooms[r]['num']}"
                            )
else:
    print("❌ Aucun emploi du temps trouvé")