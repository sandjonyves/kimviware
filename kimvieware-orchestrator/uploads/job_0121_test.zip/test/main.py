a=5 
b=7

if (a>b):
    print("Yo nous testons notre appication")
else:
    print("aaaah le code ne gere pas cette situation")
    print(b)
